from .classical_storage import ClassicalStorage
from .quantum_storage import QuantumStorage
